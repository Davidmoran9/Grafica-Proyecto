﻿namespace ProyectoGrafica
{
    partial class FormProyecto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureCanvas = new PictureBox();
            btnPlay = new Button();
            btnPause = new Button();
            btnStop = new Button();
            btnAdelantar = new Button();
            btnRetroceder = new Button();
            barraProgreso = new ProgressBar();
            ((System.ComponentModel.ISupportInitialize)pictureCanvas).BeginInit();
            SuspendLayout();
            // 
            // pictureCanvas
            // 
            pictureCanvas.BackColor = Color.Black;
            pictureCanvas.Dock = DockStyle.Top;
            pictureCanvas.Location = new Point(0, 0);
            pictureCanvas.Name = "pictureCanvas";
            pictureCanvas.Size = new Size(1018, 449);
            pictureCanvas.TabIndex = 0;
            pictureCanvas.TabStop = false;
            // 
            // btnPlay
            // 
            btnPlay.Location = new Point(138, 512);
            btnPlay.Name = "btnPlay";
            btnPlay.Size = new Size(94, 29);
            btnPlay.TabIndex = 7;
            btnPlay.Text = "Play";
            btnPlay.UseVisualStyleBackColor = true;
            // 
            // btnPause
            // 
            btnPause.Location = new Point(355, 512);
            btnPause.Name = "btnPause";
            btnPause.Size = new Size(94, 29);
            btnPause.TabIndex = 8;
            btnPause.Text = "Pause";
            btnPause.UseVisualStyleBackColor = true;
            // 
            // btnStop
            // 
            btnStop.Location = new Point(518, 512);
            btnStop.Name = "btnStop";
            btnStop.Size = new Size(94, 29);
            btnStop.TabIndex = 9;
            btnStop.Text = "Stop";
            btnStop.UseVisualStyleBackColor = true;
            // 
            // btnAdelantar
            // 
            btnAdelantar.Location = new Point(656, 512);
            btnAdelantar.Name = "btnAdelantar";
            btnAdelantar.Size = new Size(94, 29);
            btnAdelantar.TabIndex = 10;
            btnAdelantar.Text = "Adelantar";
            btnAdelantar.UseVisualStyleBackColor = true;
            // 
            // btnRetroceder
            // 
            btnRetroceder.Location = new Point(822, 512);
            btnRetroceder.Name = "btnRetroceder";
            btnRetroceder.Size = new Size(94, 29);
            btnRetroceder.TabIndex = 11;
            btnRetroceder.Text = "Retroceder";
            btnRetroceder.UseVisualStyleBackColor = true;
            // 
            // barraProgreso
            // 
            barraProgreso.Location = new Point(539, 611);
            barraProgreso.Name = "barraProgreso";
            barraProgreso.Size = new Size(125, 29);
            barraProgreso.TabIndex = 12;
            // 
            // FormProyecto
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1018, 690);
            Controls.Add(barraProgreso);
            Controls.Add(btnRetroceder);
            Controls.Add(btnAdelantar);
            Controls.Add(btnStop);
            Controls.Add(btnPause);
            Controls.Add(btnPlay);
            Controls.Add(pictureCanvas);
            Name = "FormProyecto";
            Text = "FormProyecto";
            ((System.ComponentModel.ISupportInitialize)pictureCanvas).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureCanvas;
        private Button btnPlay;
        private Button btnPause;
        private Button btnStop;
        private Button btnAdelantar;
        private Button btnRetroceder;
        private ProgressBar barraProgreso;
    }
}