﻿using System;
using System.Drawing;
using System.Windows.Forms;
using ProyectoGrafica.Graficos;

namespace ProyectoGrafica
{
    public partial class FormProyecto : Form
    {
        private System.Windows.Forms.Timer timerAnimacion;
        private System.Windows.Forms.Timer timerProgreso;
        private ManejadorAudio manejadorAudio;
        private AnalizadorAudio analizadorAudio;
        private RenderizadorEsfera renderizadorEsfera;
        private bool reproduciendo = false;

        public FormProyecto()
        {
            InitializeComponent();
            this.DoubleBuffered = true;

            manejadorAudio = new ManejadorAudio();
            analizadorAudio = new AnalizadorAudio();
            renderizadorEsfera = new RenderizadorEsfera(pictureCanvas);

            pictureCanvas.Paint += PictureCanvas_Paint;

            timerAnimacion = new System.Windows.Forms.Timer();
            timerAnimacion.Interval = 16; // ~60 FPS
            timerAnimacion.Tick += TimerAnimacion_Tick;

            timerProgreso = new System.Windows.Forms.Timer();
            timerProgreso.Interval = 100;
            timerProgreso.Tick += TimerProgreso_Tick;

            try
            {
                string rutaArchivo = "TheFatRat-Monody-_feat.-Laura-Brehm_.wav";
                manejadorAudio.InicializarAudio(rutaArchivo);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar el archivo de audio: " + ex.Message);
            }

            btnPlay.Click += (s, e) =>
            {
                manejadorAudio.Reproducir();
                reproduciendo = true;
                timerAnimacion.Start();
                timerProgreso.Start();
            };

            btnPause.Click += (s, e) =>
            {
                manejadorAudio.Pausar();
                reproduciendo = false;
                timerAnimacion.Stop();
                timerProgreso.Stop();
            };

            btnStop.Click += (s, e) =>
            {
                manejadorAudio.Detener();
                reproduciendo = false;
                timerAnimacion.Stop();
                timerProgreso.Stop();
                barraProgreso.Value = 0;
            };

            btnAdelantar.Click += (s, e) =>
            {
                manejadorAudio.Adelantar(5); // Adelanta 5 segundos
            };

            btnRetroceder.Click += (s, e) =>
            {
                manejadorAudio.Retroceder(5); // Retrocede 5 segundos
            };

            barraProgreso.MouseDown += (s, e) => timerProgreso.Stop();
            barraProgreso.MouseUp += (s, e) =>
            {
                float progreso = barraProgreso.Value / 100f;
                manejadorAudio.IrAProgreso(progreso);
                if (reproduciendo) timerProgreso.Start();
            };
        }

        private void TimerAnimacion_Tick(object sender, EventArgs e)
        {
            if (reproduciendo)
            {
                float volumenActual = manejadorAudio.ObtenerVolumenActual();
                analizadorAudio.ActualizarAnalisis(volumenActual);
                renderizadorEsfera.ActualizarAnimacion(analizadorAudio);
                pictureCanvas.Invalidate();
            }
        }

        private void TimerProgreso_Tick(object sender, EventArgs e)
        {
            float progreso = manejadorAudio.ObtenerProgreso(); // Valor entre 0 y 1
            barraProgreso.Value = Math.Min(barraProgreso.Maximum, (int)(progreso * barraProgreso.Maximum));
        }

        private void PictureCanvas_Paint(object sender, PaintEventArgs e)
        {
            renderizadorEsfera.Renderizar(e.Graphics, analizadorAudio);
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            base.OnFormClosing(e);
            manejadorAudio?.Dispose();
        }
    }
}
